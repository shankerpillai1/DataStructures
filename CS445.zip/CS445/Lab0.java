public class Lab0
{
	public static void main( String args[] )
	{
		System.out.println(	"Lab0 is not worth any grading credits. By uploading it you are:\n" + 
		"1: verifying you have figured out the VPN or Virtual Labs needed to reach the handin portal.\n" + 
		"2: verifying that your login credentials are accepted by the portal to let you hand it in.\n" + 
		"3: verifying you can edit,compile and execute this program on your computer via command line.\n" +
		"4: asserting that and compiled + executed this file on the command line using the javac and\n" + 
		"  java commands yourself rather than using ecclipse, netbeans etc. type programs.\n" );
	} // END MAIN
}